import sys, os, argparse
from random import shuffle


def main(qs_path):
  Qs = []
  with open(qs_path, 'r') as qs_file:
    t = [l.strip() for l in qs_file]
    Qs = zip(t[::2], t[1::2])

  while True:
    shuffle(Qs)
    os.system('clear')
    print "############ Pocetak pitanja #################"
    raw_input()

    for q, a in Qs:
      os.system('clear')

      print q
      raw_input()
      print a
      raw_input()


if __name__ == '__main__':
  parser = argparse.ArgumentParser(description='BIBTEO flashnotes')
  parser.add_argument('questions_file', help='File containing questions and answers separated with newline"')
  args = parser.parse_args()

  if not os.path.isfile(args.questions_file):
        print 'Arguments not valid'
        parser.print_help()
        parser.exit()
  main(args.questions_file)
